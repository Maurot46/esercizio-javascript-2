var nome = 'Aldo';
let tipologia = 'cliente';
const costante = '3.14';

document.getElementById('concatena').innerHTML = `${nome}, ${tipologia}, ${costante}`;

var testo = `${nome}, ${tipologia}, ${costante}`;
document.getElementById('concatena2').innerHTML = testo;
/*var let var*/
var cliente1 = 'Mario';
var cliente2 = 'Carla'
{
    let cliente1 = 'Carla';
    document.getElementById('let').innerHTML = cliente1;
}
document.getElementById('var').innerHTML = cliente1;
document.getElementById('final').innerHTML = cliente1;


var cliente3 = 'Mario';
document.getElementById('let2').innerHTML = cliente3;

{
    let cliente1 = 'Carla';
    document.getElementById('let3').innerHTML = cliente1;
}

document.getElementById('final2').innerHTML = cliente2;
/*-----------------------------------------------------------*/
var inizio = 15;
var addizione = inizio + inizio;

document.getElementById('iniziale').innerHTML += inizio;/*inizio*/
document.getElementById('valore1').innerHTML += `${addizione}`;
var incremento = ++addizione;
document.getElementById('valore1').innerHTML += `, ${incremento}`;

var sottrazione = 10;
sottrazione = inizio - sottrazione;
document.getElementById('valore2').innerHTML += sottrazione;
var decremento = sottrazione--
document.getElementById('valore2').innerHTML += `, ${sottrazione}`;

var moltiplicazione = 3;
moltiplicazione = inizio * moltiplicazione;
document.getElementById('valore3').innerHTML += moltiplicazione;

var divisione = 3;
divisione = inizio / divisione;
document.getElementById('valore4').innerHTML += divisione;

var concatenazione = ' è un numero'
concatenazione = inizio + concatenazione;
document.getElementById('valore5').innerHTML += concatenazione;